#include "httpSim.h"
using namespace std;

/* Function Declarations */
void checkFlag(int index, char *argv[]);


/* Global Variable Declarations */
int PORT = 8080; 		// default port value
char *URL; // default directory value
char *FILENAME;


int main (int argc, char *argv[]) {

    if (argc == 2) // zero optional flags set
        ;// do nothing
    else if (argc == 4) // one optional flags set
        checkFlag(2, argv);
    else if (argc == 6) { // two optional flags set
        checkFlag(2, argv);
        checkFlag(4, argv);
    }
    else
       stateProperUsageAndDie();

   	URL = argv[1];




	return 0;
}


/*  checkFlag
    input       - index and the arguments
    output      - none
    description - checks the optional flag and sets global variables accordingly
*/
void checkFlag(int index, char *argv[]) {
            if (strcmp("-p", argv[index]) == 0)
                PORT = atoi(argv[index+1]);
            else if (strcmp("-o", argv[index]) == 0)
                FILENAME = argv[index+1];
            else
                stateProperUsageAndDie();
}

