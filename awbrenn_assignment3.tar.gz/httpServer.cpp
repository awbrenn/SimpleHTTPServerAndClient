#include "httpSim.h"
using namespace std;


/* function declarations */
int handleHTTPRequest(int clientSock);


/* global variable declarations */
unsigned short PORT = 8080;	// default port value
char *DIRECTORY;


int main (int argc, char *argv[]) {
	int serverSock;
    struct sockaddr_in serverAddr; /* Local address */
    struct sockaddr_in clientAddr; /* Client address */
    int clientSock;
    unsigned int clientLen;

    if (argc == 1) // zero optional flags set
    	; // do nothing
   	else if (argc == 2)
   		DIRECTORY = argv[1];
    else if (argc == 3 && strcmp("-p", argv[1]) == 0)
    	PORT = (unsigned short) atoi(argv[2]);
    else if (argc == 4 && strcmp("-p", argv[1]) == 0) {
		PORT = atoi(argv[2]);
		DIRECTORY = argv[3];
    }
    else
       stateProperUsageAndDie();

   /* Create socket for sending/receiving datagrams */
    if ((serverSock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
        dieWithError((char *)"socket() failed");

    /* Construct local address structure */
    memset(&serverAddr, 0, sizeof(serverAddr));   /* Zero out structure */
    serverAddr.sin_family = AF_INET;                /* Internet address family */
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    serverAddr.sin_port = htons(PORT);      /* Local port */

    /* Bind to the local address */
    if (bind(serverSock, (struct sockaddr *) &serverAddr, sizeof(serverAddr)) < 0)
        dieWithError((char *)"bind() failed");

    if (listen(serverSock, MAX_PENDING) < 0)
        dieWithError((char *)"listen() failed");

    while(true) {
        /* setting the size of the in-out parameter */
        clientLen = sizeof(clientAddr);
        
        /* waiting for the client to connect */
        if ((clientSock = accept(serverSock, (struct sockaddr *) &clientAddr, 
		               &clientLen)) < 0)
            dieWithError((char *)"accept() failed");

        printf("Handling client %s\n", inet_ntoa(clientAddr.sin_addr));

        handleHTTPRequest(clientSock);
    }
}

int handleHTTPRequest(int clientSock) {
    char httpRequestBuffer[RECV_BUFF_SIZE];
    vector<char> httpRequest;
    int messageLen;

    if ((messageLen = recv(clientSock, httpRequestBuffer, RECV_BUFF_SIZE, 0)) < 0)
        dieWithError((char *)"recv() failed");

    while (messageLen > 0) {
        /* build the httpRequest as a char vector */
        for (int i = 0; i < messageLen; ++i) {
            httpRequest.push_back(httpRequestBuffer[i]);
        }

        if ((messageLen = recv(clientSock, httpRequestBuffer, RECV_BUFF_SIZE, 0)) < 0)
            dieWithError((char *)"recv() failed"); 
    }
    close(clientSock);

    /* print out the message recieved */
    for (int i = 0; i < (int)httpRequest.size(); ++i) {
        printf("%c", httpRequest[i]);
    }

    return 0;
}

